import { Component, OnInit } from '@angular/core';
import { MessageServiceService } from 'src/app/myServices/message-service.service';

@Component({
  selector: 'app-cena',
  templateUrl: './cena.component.html',
  styleUrls: ['./cena.component.css']
})
export class CenaComponent implements OnInit {
  cena = 0;
  msg = 1;


  constructor(private messageService: MessageServiceService) { }

  ngOnInit(): void {
  }
  btnPlusClick(event){
    this.msg+=1;
    //this.nowacena = Math.round((this.cena*this.msg)*100)/100;
   }
   btnMinusClick(event){
     if(this.msg>1)
     this.msg-=1;
    // this.nowacena = Math.round((this.cena*this.msg)*100)/100;
   }
   btnBasketClick(event){
     
    this.messageService.sendMessage(this.msg);
    

   }

}
