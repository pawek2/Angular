import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthorizationService } from '../myServices/authorization.service';
import { inject } from '@angular/core/testing';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})

export class AuthGuard implements CanActivate {
    constructor(private authService: AuthorizationService){}
    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot) {

        this.authService.CheckLog();
        if(!this.authService.IsLogged){
            return false;          
        }else{
            return true;
           
        }
    }
}
