import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wylogowany',
  templateUrl: './wylogowany.component.html',
  styleUrls: ['./wylogowany.component.css']
})
export class WylogowanyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
