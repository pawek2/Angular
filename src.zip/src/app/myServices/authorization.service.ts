import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {

  private isLogged = false;

  constructor() { }

  get IsLogged(): boolean {
    return this.isLogged;
  }
  public Login(login:string, password:string){

    if(login == 'admin' && password == 'admin'){
      localStorage.setItem('log',JSON.stringify('true'));
    }
  }
  public CheckLog() {
    this.isLogged = JSON.parse(localStorage.getItem('log'));
  }
}
