export interface PrzedmiotyModel {
title: string;
description: string;
price: number;
picture: string;
}
