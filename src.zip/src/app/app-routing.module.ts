import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProduktyComponent } from './main/produkty/produkty.component';
import { KoszykComponent } from './main/koszyk/koszyk.component';
import { AuthGuard } from './myClasses/auth-guard';
import { LoginPageComponent } from './main/login-page/login-page.component';
import { WylogowanyComponent } from './wylogowany/wylogowany.component';



const routes: Routes = [  {path:'',redirectTo: 'index.html', pathMatch: 'full'},
{path:'produkty',component: ProduktyComponent, canActivate:[AuthGuard]},
{path:'koszyk',component: KoszykComponent, canActivate:[AuthGuard]},
{path:'logowanie',component: LoginPageComponent},
{path:'wylogowany',component: WylogowanyComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
