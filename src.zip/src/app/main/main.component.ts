import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { AuthorizationService } from 'src/app/myServices/authorization.service';


@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  log = false;
  constructor(private authService: AuthorizationService, private router:Router) { }

  ngOnInit(): void {
   this.authService.CheckLog();
   this.log = this.authService.IsLogged;
  }
btnWyloguj(event){
  localStorage.clear();
  this.authService.CheckLog();
  this.log = this.authService.IsLogged;
  this.router.navigate(['/wylogowany']);
}

}
