import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { PrzedmiotyModel } from 'src/app/myClasses/przedmioty-model';
import { LoadDataService } from 'src/app/myServices/load-data.service';

@Component({
  selector: 'app-produkty',
  templateUrl: './produkty.component.html',
  styleUrls: ['./produkty.component.css']
})
export class ProduktyComponent implements OnInit {

przedmioty: PrzedmiotyModel[];


 constructor(private data: LoadDataService) { }

  ngOnInit(): void {

this.data.getData('../assets/przedmiot.json').subscribe(
  (d) =>{this.przedmioty = d;console.log(d)});

  }
  btnBasketClick(event){
    
  }

}
