import { Component, OnInit} from '@angular/core';
import { MessageServiceService } from 'src/app/myServices/message-service.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-koszyk',
  templateUrl: './koszyk.component.html',
  styleUrls: ['./koszyk.component.css']
})
export class KoszykComponent implements OnInit {
  subscription: Subscription;
  message = 0;
  constructor(private messageService: MessageServiceService) { 
    
    this.subscription = this.messageService.getMessage().subscribe(
    m =>{this.message = m;}
    );
  }

  ngOnInit(): void {
  }

}
