import { Component, OnInit } from '@angular/core';
import { AuthorizationService } from 'src/app/myServices/authorization.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  login='';
  password='';

  
  constructor(private authService: AuthorizationService, private router:Router) { }

  ngOnInit(): void {
    if(this.authService.IsLogged){
      this.router.navigate(['produkty']);
    }
  }
  
submit(){
    this.authService.Login(this.login,this.password);
    window.location.reload(); 
  }

}
